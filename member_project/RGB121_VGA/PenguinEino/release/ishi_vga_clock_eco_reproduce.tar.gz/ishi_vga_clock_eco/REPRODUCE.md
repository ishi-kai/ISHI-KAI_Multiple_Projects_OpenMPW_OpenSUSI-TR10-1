# クロックECO再現

これは製造レビュー対応後の現行再現セットです。内部の release/ishi_vga_grid_power_core は旧GDSの凍結入力で、そこへ移動して旧スクリプトを実行する手順ではありません。

このセットのルートに tools/APRtools と tools/TR-1um を用意し、toolchain.lock.json のURL・コミットへcheckoutしてください。APRtools 8f6962bf2df1618d633f8a81c230fec895fc83aa、PDK f408d3b5c23a8ebe44f02b0482a9270601e2880f。記録済みPCell lookup patchのみを scripts/apply_toolchain_patches.py で適用します。

`.venv/bin/python` にKLayout 0.30.6とnumpy、Pillow、KLayout CLI 0.30.9、g++、OpenSTA 2.6.0が必要です。元環境では `.tools/bin` に実行ファイルを用意しました。ツール自体は同梱しません。別版やローカルPDKへの自動代替はしません。

```sh
sha256sum -c SHA256SUMS
python3 scripts/check_toolchain.py
.venv/bin/python scripts/replay_clock_core.py --out build/new_clock_replay
.venv/bin/python scripts/test_sta_guard.py --out build/new_sta_controls
```

旧コアからFILL3を4個のBUF_X2へ交換し、DFFのクロック接続と配線を更新します。GDS SHA256 299b3203897dd4dffca7fb1a260a68dbd577c4ac4f98fb105cfe9e8579cf650c の一致を必須とし、公式DRC/MDP/strict LVSとguard付きSTAを新規実行します。描画DRC0、MDP Floating SG1は別々に判定します。

配線RC、フレーム、PVTの合格を意味しません。RTL／ゲート全状態・SPICEの再試験は、提出フォルダ側のREPRODUCE.mdを使います。保存入力やログを上書きせず新しい出力ディレクトリを指定してください。
